       <!-- footer section -->
        <footer class="footer">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-6">
                        <aside class="widget about_widgets">
                            <img src="images/logo.png" alt=""/>
                            <p> +234 70356 26626</p>
                            <p> +234 81580 73050</p>
                            <p>info@softkash.co</p>
                        </aside>
                    </div>
               <div class="col-lg-4 col-md-6">
                        <aside class="widget recent_posts">
                            <div class="singleLPost">
                                <h4><a href="#">What should you need do to get personal loan ver easay.</a></h4>
                                <span>20 days ago</span>
                                <p>
                                    Many modern alternatives often eumen incorpo
                                    other content actually detracts from...
                                </p>
                            </div>
                            <div class="singleLPost">
                                <h4><a href="#">What should you need do to get personal loan ver easay.</a></h4>
                                <span>20 days ago</span>
                                <p>
                                    Many modern alternatives often eumen incorpo
                                    other content actually detracts from...
                                </p>
                            </div>
                        </aside>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <aside class="widget subscribe_widgets">
                            <h3>Subscribe to our newsletter.</h3>
                            <form action="#" method="post">
                                <input type="email" placeholder="Email address" name="email"/>
                                <input type="text" placeholder="Phone no." name="phone"/>
                                <input type="submit" value="Subscribe now">
                            </form>
                        </aside>
                    </div>
                </div>
            </div>
        </footer>
        <!-- footer section -->

        <!-- Copyright section -->
        <section class="copyright">
            <div class="container">
                <div class="row">
                    <div class="col-sm-6">
                        
                            <p>Copyright <a href="#">EMA Finance Limited </a>. All rights reserved</p>
                    </div>

                    <div class="col-sm-6 text-right">
                        <a href="#" id="backTo"><i class="flaticon-chevron"></i></a>
                        <div class="col-sm-12 text-center" color="#e50079"> <h6>  Built by <a href="https://www.anchorit.com.ng"><strong> Anchorit </strong> </a></h6> 
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Copyright section -->

        <!-- Include All JS -->
        <script src="js/jquery.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/modernizr.custom.js"></script>
        <script src="js/jquery.themepunch.revolution.min.js"></script>
        <script src="js/jquery.themepunch.tools.min.js"></script>
        
        <script src="js/jquery-ui.js"></script>
        <script src="js/shuffle.js"></script>
        <script src="js/slick.js"></script>
        <script src="js/gmaps.js"></script>
        <script src="https://maps.google.com/maps/api/js?key=AIzaSyCysDHE3s4Qw3nTh9o58-2mJcqvR6HV8Kk"></script>
        <script src="js/owl.carousel.js"></script>
        <script src="js/theme.js"></script>